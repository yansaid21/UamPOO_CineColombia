package CineColombia.CineColombia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CineColombiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CineColombiaApplication.class, args);
	}

}
